import xmlrpc.client


def get_image_data(filename):
    with open(filename, "rb") as handle:
        image_data = xmlrpc.client.Binary(handle.read())
    return image_data


class ImageProcessorClient:
    def __init__(self):
        self.server = xmlrpc.client.ServerProxy('http://localhost:8000')

    def process_image(self, data, ops):

        # Calling the server's process_image method with the provided data and operations
        return self.server.process_image(data, ops)

import rpc_client

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
#Create an instance of the ImageProcessorClient class from the rpc_client module
client = rpc_client.ImageProcessorClient()

filename = input("Enter complete image file path: ")
if not filename.lower().endswith(tuple(ALLOWED_EXTENSIONS)):
    print("Invalid file type. Allowed file types are: ", ALLOWED_EXTENSIONS)
    exit()

set_choice = input("Choose the operation set (a/b): ")
if set_choice != 'a' and set_choice != 'b':
    print("Invalid operation set selected. Please choose 'a' or 'b'.")
    exit()
#define the set of operation
if set_choice == "a":
    operations = [{"name": "flip", "axis": "vertical"},
                  {"name": "rotate", "degrees": 60},
                  {"name": "grayscale", "scale": "yes"},
                  {"name": "resize", "size": (1000, 1000)}]
    # Get the image data from the input file
    image_data = rpc_client.get_image_data(filename)
    # Apply the operations to the image using the ImageProcessorClient object
    result = client.process_image(image_data, operations)
    # Save the processed image data to disk as "processed.jpg"
    processed_image_data = result.data

    with open("processed.jpg", "wb") as handle:
        handle.write(processed_image_data)

elif set_choice == "b":
    operations = [{"name": "rotate", "degrees": 40},
                  {"name": "flip", "axis": "horizontal"},
                  {"name": "resize", "size": (3000, 3000)},
                  {"name": "thumbnail", "thumb": (300, 300)},
                  {"name": "grayscale", "scale": "yes"},
                  {"name": "rotate_left_right", "side": "right"},
                  {"name": "resize", "size": (5000, 5000)},
                  {"name": "thumbnail", "thumb": (300, 300)},
                  {"name": "rotate_left_right", "side": "right"}]
    # Get the image data from the input file
    image_data = rpc_client.get_image_data(filename)
    # Apply the operations to the image using the ImageProcessorClient object
    snapshot, final = client.process_image(image_data, operations)
    # Save the snapshot and final processed image data to disk as "thumbnail.jpg" and "processed.jpg", respectively
    with open("thumbnail.jpg", "wb") as handle:
        handle.write(snapshot.data)
    with open("processed.jpg", "wb") as handle:
        handle.write(final.data)

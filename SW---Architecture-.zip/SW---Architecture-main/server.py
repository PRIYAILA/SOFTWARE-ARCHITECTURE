from io import BytesIO
from PIL import Image


class ImageProcessor:

    def __init__(self):
        pass

    # Method to flip the image
    def flip_image(self, image, axis):
        if axis == "horizontal":
            print("The image is flipped horizontally")
            return image.transpose(method=Image.FLIP_LEFT_RIGHT)
        elif axis == "vertical":
            print("The image is flipped vertically")
            return image.transpose(method=Image.FLIP_TOP_BOTTOM)
        elif axis == "no":
            return image

    # Method to rotate the image
    def rotate_image(self, image, degrees):
        print("The image is rotated with " + str(degrees) + " degrees")
        return image.rotate(degrees)

    # Method to convert the image to grayscale
    def grayscale_image(self, image, scale):
        if scale == "yes":
            print("The image is grayscaled ")
            return image.convert('L')
        elif scale == "no":
            return image

    # Method to resize the image
    def resize_image(self, image, size):
        print("The image is resized ")
        return image.resize(size)

    # Method to create a thumbnail of the image
    def thumbnail_image(self, image, thumb):
        print("The image thumbnail of 300*300 size is saved")
        width, height = thumb
        image.thumbnail((width, height))
        return image

    # Method to rotate the image left or right
    def rotate_left_right_image(self, image, side):
        if side == "left":
            print("The image is rotated left")
            return image.transpose(method=Image.ROTATE_90)
        elif side == "right":
            print("The image is rotated right")
            return image.transpose(method=Image.ROTATE_270)
        elif side == "no":
            return image

    # Method to process the image with the given operations
    def process_image(self, image_data, operations):
        image = Image.open(BytesIO(image_data.data))
        thumbnail = None

        if not operations:
            return image
        # Loop through the given operations and perform the corresponding image processing operations
        for op in operations:
            if op["name"] == "flip":
                image = self.flip_image(image, op["axis"])
                print(image.width, image.height)
            elif op["name"] == "rotate":
                image = self.rotate_image(image, op["degrees"])
                print(image.width, image.height)
            elif op["name"] == "grayscale":
                image = self.grayscale_image(image, op["scale"])
                print(image.width, image.height)
            elif op["name"] == "resize":
                image = self.resize_image(image, op["size"])
                print(image.width, image.height)
            elif op["name"] == "rotate_left_right":
                image = self.rotate_left_right_image(image, op["side"])
                print(image.width, image.height)
            elif op["name"] == "thumbnail":
                thumbnail = image.copy()
                thumbnail = self.thumbnail_image(thumbnail, op["thumb"])
                print(image.width, image.height)

        # If a thumbnail was created, save both the thumbnail and the processed image and return them
        if thumbnail is not None:
            with BytesIO() as snap, BytesIO() as output:
                thumbnail.save(snap, format='JPEG')
                image.save(output, format='JPEG')
                return snap.getvalue(), output.getvalue()
        else:
            with BytesIO() as output:
                image.save(output, format='JPEG')
                return output.getvalue()


MONGO_URI = "mongodb+srv://Madhu:1234@cluster0.yhb6mpn.mongodb.net/?retryWrites=true&w=majority"
MONGO_DBNAME = "Address_Manager"

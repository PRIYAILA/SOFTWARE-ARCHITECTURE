from flask_pymongo import PyMongo

mongodb=PyMongo()



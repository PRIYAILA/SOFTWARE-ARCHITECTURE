import xmlrpc.server
import server

#Set allow_none to True to allow passing of None values as parameters or return values
rpc_server = xmlrpc.server.SimpleXMLRPCServer(('localhost', 8000), allow_none=True)

#Register an instance of the ImageProcessor class with the XML-RPC server
rpc_server.register_instance(server.ImageProcessor())

#Start serving requests indefinitely
rpc_server.serve_forever()
